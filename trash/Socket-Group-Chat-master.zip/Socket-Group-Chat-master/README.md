# Socket-Group-Chat
多人聊天程序的雏形。

coding 环境：VS2015 WIN10

测试环境：VM虚拟机-->XP系统和主机WIN10

语言：C

功能：基于服务器转发消息的1V1聊天

主要原理：client都连上server，然后server通过判断client socket的不同进而转发消息。

